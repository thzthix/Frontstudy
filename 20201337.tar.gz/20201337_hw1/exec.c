#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){

	char* argv[2];
	argv[0]="ls";
	argv[1]=0;

	int pid=fork();
	int status;

	if(pid>0){
		printf("parent: child=%d\n",pid);
		pid=wait(&status);
		printf("child %d is done\n",pid);
	}else if(pid==0){
		printf("child:exiting\n");
		execve("/bin/ls",argv,NULL);
	}else{
		printf("fork error\n");
	}
	return 0;

}
