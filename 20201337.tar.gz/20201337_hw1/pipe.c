#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(){
	int p[2];
	char* argv1[3];

	argv1[0]="echo";
	argv1[1]="hello world";
	argv1[2]=0;

	char* argv2[2];

	argv2[0]="wc";
	argv2[1]=0;




	pipe(p);
	if(fork()==0){
		dup2(p[1],1);
		close(p[0]);
		close(p[1]);
		execve("/bin/echo",argv1,NULL);

	}else{
		wait(0);
		dup2(p[0],0);
		close(p[1]);
		close(p[0]);
		execve("/usr/bin/wc",argv2,NULL);
		
	}

	

}
